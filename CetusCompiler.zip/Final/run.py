#!/usr/bin/env python3

import subprocess
import sys

def runAutomatedAST():
    subprocess.call("./make.sh", cwd="AST")
    subprocess.call("cat testoutput.out",shell=True, cwd="AST")
    print("Test Complete!")
    print("The AST's can be viewed in the AST folder.")
    print("\n")
    print("\n")

def runManualAST(message):
    subprocess.call("make clean",shell=True, cwd="AST")
    subprocess.call("make csimple",shell=True, cwd="AST")
    command = "dos2unix " + message
    subprocess.call(command,shell=True, cwd="AST/tests")
    command = "./csimple <  tests/"+ message + " >> testoutput.dot"
    subprocess.call(command,shell=True, cwd="AST")
    command = "./csimple <  tests/"+ message + " >> testoutput.out"
    subprocess.call(command,shell=True, cwd="AST")
    subprocess.call("dot -Tps testoutput.dot > testoutput.ps",shell=True, cwd="AST")
    subprocess.call("ps2pdf testoutput.ps testoutput.pdf",shell=True, cwd="AST")
    subprocess.call("cat testoutput.out",shell=True, cwd="AST")
    print("Test Complete!")
    print("The AST's can be viewed in the AST folder.")
    print("\n")
    print("\n")

def runAutomatedComp():
    subprocess.call("./make.sh",cwd="Compiler")
    print("Testing Validtest1:")
    subprocess.call("./start1",cwd="Compiler")
    print("Testing Validtest2:")
    subprocess.call("./start2",cwd="Compiler")
    print("Testing Validtest3:")
    subprocess.call("./start3",cwd="Compiler")
    print("Testing Validtest4:")
    subprocess.call("./start4",cwd="Compiler")
    print("Testing Validtest5:")
    subprocess.call("./start5",cwd="Compiler")
    print("Testing Validtest6:")
    subprocess.call("./start6",cwd="Compiler")
    print("Testing Validtest7:")
    subprocess.call("./start7",cwd="Compiler")
    print("Testing Validtest8:")
    subprocess.call("./start8",cwd="Compiler")
    print("Test Complete!")
    print("\n")
    print("\n")

def runManualCompiler(message):
    subprocess.call("make clean",shell=True, cwd="Compiler")
    subprocess.call("make csimple",shell=True, cwd="Compiler")
    command = "./csimple <  tests/"+ message + " > testoutput.s"
    subprocess.call(command,shell=True, cwd="Compiler")
    subprocess.call("gcc -c -m32 -o csimple.o testoutput.s",shell=True, cwd="Compiler")
    subprocess.call("gcc -c -m32 -o start.o start.c",shell=True, cwd="Compiler")
    subprocess.call("gcc -m32 -o start1 start.o csimple.o",shell=True, cwd="Compiler")
    subprocess.call("./start1",shell=True, cwd="Compiler")
    print("Test Complete!")
    print("\n")
    print("\n")

if __name__ == '__main__':
    print("Welcome to the Cetus Compiler!")
    while (True):
        print("Enter the number to test the component:")
        print("1. View the AST and Token output")
        print("2. View the compiler executable output")
        print("3. Exit GUI")
        response = input("Enter #:")
        if (int(response) == 1):
            print("Enter way you want to test the component:")
            print("1. Provided Test Files")
            print("2. Own Csimple Source Files")
            response2 = input("Enter #:")
            if (int(response2) == 1):
                print("Running Automated Tests. Please Wait!")
                print("\n")
                print("\n")
                runAutomatedAST()
            elif (int(response2) == 2):
                print("Make sure the file you are inputting is in AST/tests")
                message = input("Enter the filename:")
                print("Running Manual Tests. Please Wait!")
                print("\n")
                print("\n")
                runManualAST(str(message))
        elif (int(response) == 2):
            print("Enter way you want to test the component:")
            print("1. Provided Test Files")
            print("2. Own Csimple Source Files")
            response2 = input("Enter #:")
            if (int(response2) == 1):
                print("Running Automated Tests. Please Wait!")
                print("\n")
                print("\n")
                runAutomatedComp()
            elif (int(response2) == 2):
                print("Make sure the file you are inputting is in AST/tests")
                message = input("Enter the filename:")
                print("Running Manual Tests. Please Wait!")
                print("\n")
                print("\n")
                runManualCompiler(str(message))
        elif (int(response) == 3):
            break
        else:
            print("___Please Enter Valid Input.___")
            print("\n")
            print("\n")
    print("Thank you for using our compiler!")
    print("\n")
    print("\n")
    sys.exit(0)
