# CS467 Cetus-1

### Group Members

* Joshua Rogers

* Marcus Griffiths

* Brandon Lo

---
#### Please look into other child directories for compilation instructions

* Else you can just run "run.py" with
```
./run.py
```

and follow the on screen prompts
