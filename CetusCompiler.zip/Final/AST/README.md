# CS467 Cetus-1 AST

### Automatic Test Instructions
* There is a python3 script called “run.py” that can be run, located in the root directory. Follow the on screen prompts in order to automatically run all the tests. After checking if it is executable, run
```
./run.py
```
---
* In order to run our compiler with the provided Csimple test files, make sure that the make.sh bash file is executable. If it is not run
```
chmod u+x make.sh
```
Then you can run the bash script with
```
./make.sh
```
 Then you can run the executables, labeled start1, start2, start3, and start4 with
 ```
 ./[executable]
 ```
---
* If you would like to run the tests individually you can run
```
make test(x)
```
, where x = 1, 2, 3, or 4. It only tests the valid test files, or else the type checker would just exit with an error and not produce a tree

### Manual Test Instructions

* There is a python3 script called “run.py” that can be run, located in the root directory. After checking if it is executable, run
```
./run.py
```
Follow the on screen prompts in order to manually enter the filename.

---
* If you don’t want to follow the python3 script there is a bash script “tree” located in the “Compiler” folder. Run using the syntax
```
./tree <filename>
```
where filename contains your Csimple code.

---
* If you want to manually input Csimple code you can run
```
./csimple
```

and it will ask for input. It will continue scanning unless you enter invalid Csimple code, then it will output an error.  It will only scan/parse/type check since  it does not output to a file.

---

* If you do want to run any scripts and would like to output a tree in a pdf without the python script, you need to have the source code in a file. Here are the steps you need need to run. Make sure your working directory is the “AST” folder

1.
```
make csimple
```

2.
```
dos2unix [source code filename]
```

3.
```
./csimple < [source code filename] >> testoutput.out
```
 * Note: You can stop here if you just want to view the parser/scanner output

4.
```
./csimple <  [source code filename] >> testoutput.dot
```

5.
```
dot -Tps testoutput.dot > testoutput.ps
```

6.
```
Ps2pdf testoutput.ps testoutput.pdf
```
