#!/bin/bash
make clean 
make all -i > build.log 2>&1
make cleanobj
