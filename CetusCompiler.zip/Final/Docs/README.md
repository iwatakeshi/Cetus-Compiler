# CS467 Cetus-1

### Group Members

* Joshua Rogers

* Marcus Griffiths

* Brandon Lo

---
### Contents
* #### CSimple Language Manual

  * [Source](http://www.cs.ucsb.edu/~chris/teaching/cs160/projects/language.html)

* #### A copy of our final report
